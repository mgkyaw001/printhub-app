# PrintHub – USB All-in-One Printer (Android Native)

This is a complete Android Studio & AndroidIDE project for USB OTG printing with:
- Android USB Host API
- Full Color RGB & Monochrome Floyd-Steinberg dithering
- Android Print Framework
- PDF & Document rendering
- Myanmar Unicode support

## How to Build APK with AndroidIDE (on Phone)
1. Install AndroidIDE from F-Droid or GitHub (AndroidIDEOfficial/AndroidIDE).
2. Extract this ZIP file into your phone's storage.
3. Open AndroidIDE, select 'Open Project', and choose this extracted folder.
4. AndroidIDE will sync Gradle automatically.
5. Tap the 'Build' hammer icon or 'Run' (Play) button to build and install the APK!

## How to Build with Android Studio (on PC)
1. Open this directory in Android Studio.
2. Allow Gradle sync to complete.
3. Connect phone via USB or build APK via 'Build' -> 'Build APK(s)'.
